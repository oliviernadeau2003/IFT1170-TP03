//* Auteur : Olivier Nadeau [IFT1170 Automne 2024]

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        TP03_1170_NumA.afficher();
        TP03_1170_NumB.afficher();
        TP03_1170_NumC.afficher();
    }
}